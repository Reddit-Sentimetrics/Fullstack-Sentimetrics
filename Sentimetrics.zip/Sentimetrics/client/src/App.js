import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import LoginPage from './components/LoginPage';
import HomePage from './components/HomePage';
import AdminPage from './components/AdminPage';
import FollowedSubreddits from './components/FollowedSubreddits';
import AdminPageSub from './components/AdminPageSub';
import React, { useState } from 'react';

function App() {
  const [isAdmin, setIsAdmin] = useState(false);
  const [username, setUsername] = useState('');


  const handleLogin = async (username, password) => {
    try {
      const response = await fetch('http://localhost:8000/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
      });
  
      const data = await response.json();
      if (response.status === 200) {
        setIsAdmin(data.isAdmin);
        setUsername(username); // Set the username state
      } else {
        alert('Invalid username or password');
      }
    } catch (error) {
      console.error('Error fetching isAdmin flag:', error);
    }
  };
  

  return (
    <Router>
      <div className="App">
        <Routes>
          <Route
            path="/login"
            element={<LoginPage handleLogin={handleLogin} />}
          />
          <Route
            path="/home"
            element={<HomePage isAdmin={isAdmin} username={username} />}
          />
          {/* ... other routes */}
          {/* <Route path="/admin" element={<AdminPage isAdmin={isAdmin}/>} />   */}
          <Route path="/adminPage" element={<AdminPageSub isAdmin={isAdmin}/>}/>
          <Route path="/followedSubreddits" element={<FollowedSubreddits username={username}/>} />
        </Routes>

        
      </div>
    </Router>
  );
}

export default App;
