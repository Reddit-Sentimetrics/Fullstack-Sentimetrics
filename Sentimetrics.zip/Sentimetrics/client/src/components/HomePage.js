import React, { Fragment, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
// import useFetchData from './useFetchData';
// import DataDisplay from './DataDisplay';
import SubredditTable from './SubredditTable';
import AdminPage from './AdminPage';
import AdminSubredditTable from './AdminSubredditTable';

  
const HomePage = ({isAdmin,username}) => {
  // const basicRetrievalData = useFetchData('/basic-retrieval');
  // const orderedResultsData = useFetchData('/ordered-results');
  // const nestedRetrievalData = useFetchData('/nested-retrieval');
  // const joinedTablesData = useFetchData('/joined-tables');
  const [subreddits, setSubreddits] = useState([]);
  // navigate = useNavigate();
  
  const navigate = useNavigate();

  const handleFollowedSubreddits = () => {
    navigate('/followedSubreddits');
  };

  const handleAdminPage = () => {
    navigate('/adminPage');
  };

  useEffect(() => {
    const fetchSubreddits = async () => {
      try {
        const response = await fetch('http://localhost:8000/subreddits');
        const data = await response.json();
        setSubreddits(data);
      } catch (error) {
        console.error('Error fetching subreddits:', error);
      }
    };

    if (!isAdmin) {
      fetchSubreddits();
    }
  }, [isAdmin]);

  return (
    <div>
      <h1>Home Page</h1>
      
      {isAdmin ? (
        <div>
          {/* Admin-specific homepage content */}
          <h1>Welcome Admin</h1>
          <Fragment>
            <button onClick={handleAdminPage}>Subreddit Management</button>
            
            {/* <button onClick={() => navigate('/admin')}>User Administration</button> */}
            {/* <AdminSubredditTable username={username} subreddits={subreddits}/> */}
          </Fragment>
          
        </div>
      ) : (
        <div>
          {/* Regular user homepage content */}
          <h1>Welcome Client</h1>
          <Fragment>
          
          {/* button to link to page /followedSubreddits*/}
          <button onClick={handleFollowedSubreddits}>Your Subreddits</button>
          </Fragment>
          <Fragment>
          <SubredditTable username={username} subreddits={subreddits}/>
          </Fragment>
        </div>
      )}
    </div>
  );
};

export default HomePage;
