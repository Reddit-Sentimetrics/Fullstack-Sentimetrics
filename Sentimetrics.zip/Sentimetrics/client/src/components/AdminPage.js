import React, { useState } from 'react';

const AdminPage = ({isAdmin}) => {
  const [insertData, setInsertData] = useState({
    username: '',
    firstName: '',
    lastName: '',
    email: '',
  });
  const [updateData, setUpdateData] = useState({
    username: '',
    firstName: '',
    lastName: '',
  });

  const handleInputChange = (event, setData) => {
    const { name, value } = event.target;
    setData((prevState) => ({ ...prevState, [name]: value }));
  };

  const handleInsert = async () => {
    try {
      await fetch('http://localhost:8000/insert-operation', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(insertData),
      });
      alert('User inserted successfully');
    } catch (error) {
      console.error('Error inserting user:', error);
    }
  };

  const handleUpdate = async () => {
    try {
      await fetch('http://localhost:8000/update-operation', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(updateData),
      });
      alert('User updated successfully');
    } catch (error) {
      console.error('Error updating user:', error);
    }
  };

  return (
    <div>
      <h1>Admin Page</h1>
      <div>
        <h2>Insert User</h2>
        <input
          name="username"
          placeholder="Username"
          value={insertData.username}
          onChange={(event) => handleInputChange(event, setInsertData)}
        />
        <input
          name="firstName"
          placeholder="First Name"
          value={insertData.firstName}
          onChange={(event) => handleInputChange(event, setInsertData)}
        />
        <input
          name="lastName"
          placeholder="Last Name"
          value={insertData.lastName}
          onChange={(event) => handleInputChange(event, setInsertData)}
        />
        <input
          name="email"
          placeholder="Email"
          value={insertData.email}
          onChange={(event) => handleInputChange(event, setInsertData)}
        />
        <button onClick={handleInsert}>Insert User</button>
      </div>
      <div>
        <h2>Update User</h2>
        <input
          name="username"
          placeholder="Username"
          value={updateData.username}
          onChange={(event) => handleInputChange(event, setUpdateData)}
        />
        <input
          name="firstName"
          placeholder="First Name"
          value={updateData.firstName}
          onChange={(event) => handleInputChange(event, setUpdateData)}
        />
        <input
          name="lastName"
          placeholder="Last Name"
          value={updateData.lastName}
          onChange={(event) => handleInputChange(event, setUpdateData)}
        />
        <button onClick={handleUpdate}>Update User</button>
      </div>
    </div>
    );
    };

    export default AdminPage;
