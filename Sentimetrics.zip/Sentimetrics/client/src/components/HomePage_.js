import React, { useState, useEffect, Fragment } from "react";


//BASIC RETRIEVAL
const BasicRetrieval = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const response = await fetch("/basic-retrieval");
      const jsonData = await response.json();
      setData(jsonData);
    };

    fetchData();
  }, []);

  return (
    <div>
      <h2>Basic Retrieval</h2>
      <ul>
        {data.map((item, index) => (
          <li key={index}>{JSON.stringify(item)}</li>
        ))}
      </ul>
    </div>
  );
};

const OrderedResults = () => {
  // Similar to BasicRetrieval component
  const [data, setData] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const response = await fetch("/basic-retrieval");
      const jsonData = await response.json();
      setData(jsonData);

    };

    fetchData();
  }, []);

  return (
    <div>
      <h2>Basic Retrieval</h2>
      <ul>
        {data.map((item, index) => (
          <li key={index}>{JSON.stringify(item)}</li>
          
        ))}
      </ul>
    </div>
  );
};

const NestedRetrieval = () => {
  // Similar to BasicRetrieval component
  const [data, setData] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const response = await fetch("/basic-retrieval");
      const jsonData = await response.json();
      setData(jsonData);
    };

    fetchData();
  }, []);

  return (
    <div>
      <h2>Basic Retrieval</h2>
      <ul>
        {data.map((item, index) => (
          <li key={index}>{JSON.stringify(item)}</li>
        ))}
      </ul>
    </div>
  );
};

const JoinedTables = () => {
  // Similar to BasicRetrieval component
  const [data, setData] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const response = await fetch("/basic-retrieval");
      const jsonData = await response.json();
      setData(jsonData);
    };

    fetchData();
  }, []);

  return (
    <div>
      <h2>Basic Retrieval</h2>
      <ul>
        {data.map((item, index) => (
          <li key={index}>{JSON.stringify(item)}</li>
        ))}
      </ul>
    </div>
  );
};

const InsertOperation = () => {
  const handleClick = async () => {
    await fetch("/insert-operation");
  };

  return (
    <div>
      <h2>Insert Operation</h2>
      <button onClick={handleClick}>Insert</button>
    </div>
  );
};

const UpdateOperation = () => {
  const handleClick = async () => {
    await fetch("/update-operation");
  };

  return (
    <div>
      <h2>Update Operation</h2>
      <button onClick={handleClick}>Update</button>
    </div>
  );
};

const DeleteOperation = () => {
  const handleClick = async () => {
    await fetch("/delete-operation");
  };

  return (
    <div>
      <h2>Delete Operation</h2>
      <button onClick={handleClick}>Delete</button>
    </div>
  );
};

const HomePage = () => {
  return (
    <div>
      <h1>Home Page</h1>
      <Fragment>
        <BasicRetrieval />
      </Fragment>
      <Fragment>
        <OrderedResults />
      </Fragment>
      <Fragment>
        <NestedRetrieval />
      </Fragment>
      <Fragment>
        <JoinedTables />
      </Fragment>
      <Fragment>
        <InsertOperation />
      </Fragment>
      <Fragment>
        <UpdateOperation />
      </Fragment>
      <Fragment>
        <DeleteOperation />
      </Fragment>
    </div>
  );
};

export default HomePage;
