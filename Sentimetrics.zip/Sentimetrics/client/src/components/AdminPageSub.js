import React, { useState, useEffect } from "react";

const AdminPageSub = () => {
  const [subreddits, setSubreddits] = useState([]);
  const [inputValues, setInputValues] = useState({});

  useEffect(() => {
    fetchSubreddits();
  }, []);

  const fetchSubreddits = async () => {
    const response = await fetch("http://localhost:8000/get-subreddits");
    const data = await response.json();
    console.log(data);
    setSubreddits(data);
  };

  const handleScoreChange = (event, url) => {
    const { value } = event.target;
    setInputValues((prevState) => ({ ...prevState, [url]: value }));
  };

  const handleUpdate = async (url) => {
    const score = inputValues[url];
    try {
      await fetch("http://localhost:8000/update-score", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ url, score }),
      });
      alert("Score updated successfully");
      fetchSubreddits(); // Refresh the data after a successful update
    } catch (error) {
      console.error("Error updating score:", error);
    }
  };

  return (
    <div>
      <h1>Admin Page</h1>
      {subreddits.map((subreddit) => (
        <div key={subreddit.URL}>
          <h2>{subreddit.URL}</h2>
          <p>
            Sentiment Score: {subreddit.Score}
          </p>
          <input
            name="score"
            placeholder="Update Score"
            value={inputValues[subreddit.URL] || ""}
            onChange={(event) => handleScoreChange(event, subreddit.URL)}
          />

          <button onClick={() => handleUpdate(subreddit.URL)}>
            Update Score
          </button>
        </div>
      ))}
    </div>
  );
};

export default AdminPageSub;
