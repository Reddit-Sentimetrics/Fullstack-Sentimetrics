import React, {useState} from "react";

const AdminSubredditTable = ({ username, subreddits }) => {
    const [followedSubreddits, setFollowedSubreddits] = useState([]);
    const handleFollow = async (url) => {
        try {
          await fetch('http://localhost:8000/follow', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ username, url }),
          });
          setFollowedSubreddits((prevFollowedSubreddits) => [
            ...prevFollowedSubreddits,
            url,
          ]);
        } catch (error) {
          console.error('Error following subreddit:', error);
        }
      };
      
      const handleUnfollow = async (url) => {
        try {
          await fetch('http://localhost:8000/unfollow', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ username, url }),
          });
          setFollowedSubreddits((prevFollowedSubreddits) =>
            prevFollowedSubreddits.filter((item) => item !== url)
          );
        } catch (error) {
          console.error('Error unfollowing subreddit:', error);
        }
      };
      

  return (
    <table>
      <thead>
        <tr>
          <th>URL</th>
          <th>Subreddit Description</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {subreddits.map((subreddit) => (
          <tr key={subreddit.Report_id}>
            <td>{subreddit.URL}</td>
            <td>{subreddit.Subreddit_description}</td>
            <td>
              <button onClick={() => handleFollow(subreddit.URL)}>
                Follow
              </button>
              <button onClick={() => handleUnfollow(subreddit.URL)}>
                Unfollow
              </button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default AdminSubredditTable;
