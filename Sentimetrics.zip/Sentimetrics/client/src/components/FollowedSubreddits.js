import React, { useEffect, useState } from "react";

const FollowedSubreddits = ({ username }) => {
  const [followedSubreddits, setFollowedSubreddits] = useState([]);
  const [reportName, setReportName] = useState("");
  const [reportDescription, setReportDescription] = useState("");

  useEffect(() => {
    const fetchFollowedSubreddits = async () => {
      try {
        const response = await fetch(
          `http://localhost:8000/followedSubreddits/${username}`
        );
        const data = await response.json();
        setFollowedSubreddits(data);
      } catch (error) {
        console.error("Error fetching followed subreddits:", error);
      }
    };

    fetchFollowedSubreddits();
  }, [username]);

  const handleReportSubmit = async (event,username) => {
    event.preventDefault();

    try {
      const response = await fetch("http://localhost:8000/create-report", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ reportName, reportDescription, username }),
      });

      if (response.status === 200) {
        alert("Report created successfully");
      } else {
        alert("Error creating report");
      }
    } catch (error) {
      console.error("Error creating report:", error);
    }
  };

  const sortByScore = () => {
    const sortedSubreddits = [...followedSubreddits].sort((a, b) => b.Score - a.Score);
    setFollowedSubreddits(sortedSubreddits);
  };
  
  const sortByUrl = () => {
    const sortedSubreddits = [...followedSubreddits].sort((a, b) => a.URL.localeCompare(b.URL));
    setFollowedSubreddits(sortedSubreddits);
  };
  

  return (
    <div>
      <h1>{username}'s Subreddits</h1>
      <form onSubmit={(event) => handleReportSubmit(event,username)}>
        <label htmlFor="reportName">Report Name:</label>
        <input
          type="text"
          id="reportName"
          value={reportName}
          onChange={(event) => setReportName(event.target.value)}
        />
        <label htmlFor="reportDescription">Report Description:</label>
        <input
          type="text"
          id="reportDescription"
          value={reportDescription}
          onChange={(event) => setReportDescription(event.target.value)}
        />
        <button type="submit">Create Report</button>
      </form>

      <button onClick={sortByScore}>Sort by Score</button>
      <button onClick={sortByUrl}>Sort Alphabetically</button>
      <table>
        <thead>
          <tr>
            <th>URL</th>
            <th>Sentiment Score</th>
          </tr>
        </thead>
        <tbody>
          {followedSubreddits.map((subreddit) => (
            <tr key={subreddit.URL}>
              <td>{subreddit.URL}</td>
              <td>{subreddit.Score}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default FollowedSubreddits;
