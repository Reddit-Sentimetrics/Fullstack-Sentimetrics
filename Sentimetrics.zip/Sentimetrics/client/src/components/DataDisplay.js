import React from 'react';

function DataDisplay({ data }) {
  if (data.isLoading) {
    return <div>Loading data...</div>;
  }

  if (!Array.isArray(data.data)) {
    console.error("Data is not an array:", data);
    return <div>Error: Data is not an array</div>;
  }

  return (
    <div>
      {data.data.map((item, index) => {
        console.log('Item:', item);
        return (
          <div key={index}>
            <p>ID: {item.id}</p>
            <p>Name: {item.name}</p>
            <p>Value: {item.value}</p>
          </div>
        );
      })}
    </div>
  );
}

export default DataDisplay;
