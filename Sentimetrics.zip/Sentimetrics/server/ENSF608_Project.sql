--
-- PostgreSQL database dump
--

-- Dumped from database version 15.2
-- Dumped by pg_dump version 15.1

-- Started on 2023-03-12 12:35:56 MDT

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "RedditSentimetrics";
--
-- TOC entry 3687 (class 1262 OID 16430)
-- Name: RedditSentimetrics; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "RedditSentimetrics" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = icu LOCALE = 'en_US.UTF-8' ICU_LOCALE = 'en-US';


ALTER DATABASE "RedditSentimetrics" OWNER TO postgres;

\connect "RedditSentimetrics"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 4 (class 2615 OID 2200)
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- TOC entry 3688 (class 0 OID 0)
-- Dependencies: 4
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 214 (class 1259 OID 16431)
-- Name: user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."user" (
    "Username" character varying(25) NOT NULL,
    "First_Name" character varying(20),
    "Last_Name" character varying(20),
    "Preferences" character varying(25),
    "Password" character varying(25)
);


ALTER TABLE public."user" OWNER TO postgres;

--
-- TOC entry 215 (class 1259 OID 16446)
-- Name: admin; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admin (
    "Username" character varying(25),
    "First_Name" character varying(20),
    "Last_Name" character varying(20),
    "Preferences" character varying(25),
    "Password" character varying(25),
    "Permissions" character varying(25)
)
INHERITS (public."user");


ALTER TABLE public.admin OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 16580)
-- Name: client; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.client (
    "Company_Name" character varying(25),
    "Industry" character varying(25)
)
INHERITS (public."user");


ALTER TABLE public.client OWNER TO postgres;

--
-- TOC entry 220 (class 1259 OID 16498)
-- Name: date; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.date (
    "Date_id" character varying(25) NOT NULL,
    "Year" integer,
    "Month" integer,
    "Day" integer
);


ALTER TABLE public.date OWNER TO postgres;

--
-- TOC entry 224 (class 1259 OID 16648)
-- Name: email; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.email (
    "Username" character varying(25) NOT NULL,
    "Email" character varying(50) NOT NULL
);


ALTER TABLE public.email OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 16513)
-- Name: follows; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.follows (
    "Username" character varying(25) NOT NULL,
    "URL" character varying(200) NOT NULL
);


ALTER TABLE public.follows OWNER TO postgres;

--
-- TOC entry 217 (class 1259 OID 16461)
-- Name: report; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.report (
    "Report_id" character varying(25) NOT NULL,
    "Report_name" character varying(50),
    "Report_description" character varying(1000),
    "Username" character varying(25),
    "Date_id" character varying(25)
);


ALTER TABLE public.report OWNER TO postgres;

--
-- TOC entry 222 (class 1259 OID 16543)
-- Name: role; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role (
    "Role_name" character varying(25) NOT NULL,
    "Username" character varying(25) NOT NULL
);


ALTER TABLE public.role OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 16483)
-- Name: sentiment_value; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sentiment_value (
    "Sentiment_id" character varying(25) NOT NULL,
    "Score" double precision,
    "Rolling_average" double precision,
    "Date_id" character varying(25),
    "URL" character varying(200)
);


ALTER TABLE public.sentiment_value OWNER TO postgres;

--
-- TOC entry 216 (class 1259 OID 16456)
-- Name: subreddit; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subreddit (
    "URL" character varying(200) NOT NULL,
    "Member_count" integer,
    "Subreddit_description" character varying(250),
    "Report_id" character varying(25)
);


ALTER TABLE public.subreddit OWNER TO postgres;

--
-- TOC entry 218 (class 1259 OID 16473)
-- Name: topic; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.topic (
    "Topic_name" character varying(25) NOT NULL,
    "Topic_description" character varying(300),
    "URL" character varying(200) NOT NULL
);


ALTER TABLE public.topic OWNER TO postgres;

--
-- TOC entry 3672 (class 0 OID 16446)
-- Dependencies: 215
-- Data for Name: admin; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.admin ("Username", "First_Name", "Last_Name", "Preferences", "Password", "Permissions") VALUES ('BellaNguyen10', 'Isabella', 'Nguyen', 'Two-Factor Authentication', 'wZ1$rKg@4Y*q', 'Update');
INSERT INTO public.admin ("Username", "First_Name", "Last_Name", "Preferences", "Password", "Permissions") VALUES ('HarperBrowny', 'Harper', 'Brown', 'Two-Factor Authentication', 'sL9%tPp#4X*e', 'Update');


--
-- TOC entry 3680 (class 0 OID 16580)
-- Dependencies: 223
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.client ("Username", "First_Name", "Last_Name", "Preferences", "Password", "Company_Name", "Industry") VALUES ('EthanAnder12', 'Ethan', 'Anderson', 'Two-Factor Authentication', 'jM5$yHn@8Z*a', 'Apple Inc.', 'Technology');
INSERT INTO public.client ("Username", "First_Name", "Last_Name", "Preferences", "Password", "Company_Name", "Industry") VALUES ('CalexDavis', 'Caleb', 'Davis', 'Two-Factor Authentication', 'kD6^bJq@2Y*r', 'Microsoft Corporation', 'Technology');
INSERT INTO public.client ("Username", "First_Name", "Last_Name", "Preferences", "Password", "Company_Name", "Industry") VALUES ('MiaEdwards21', 'Mia', 'Edwards', 'Two-Factor Authentication', 'nF8#sGh@3T*e', 'Google LLC', 'Technology');
INSERT INTO public.client ("Username", "First_Name", "Last_Name", "Preferences", "Password", "Company_Name", "Industry") VALUES ('BenjFranklin88', 'Benjamin', 'Franklin', 'Two-Factor Authentication', 'vR4$wNt#1Z*q', 'Facebook, Inc.', 'Technology');
INSERT INTO public.client ("Username", "First_Name", "Last_Name", "Preferences", "Password", "Company_Name", "Industry") VALUES ('ChloeGarciaX', 'Chloe', 'Garcia', 'Two-Factor Authentication', 'tS2&fLp@7X*e', 'Amazon.com, Inc.', 'Technology');
INSERT INTO public.client ("Username", "First_Name", "Last_Name", "Preferences", "Password", "Company_Name", "Industry") VALUES ('WilliamHernezz', 'William', 'Hernandez', 'Two-Factor Authentication', 'aH7@uKj#5Y*r', 'Intel Corporation', 'Technology');
INSERT INTO public.client ("Username", "First_Name", "Last_Name", "Preferences", "Password", "Company_Name", "Industry") VALUES ('MadisonJohno', 'Madison', 'Johnson', 'Two-Factor Authentication', 'eQ3xBn@9Zq', 'IBM Corporation', 'Technology');
INSERT INTO public.client ("Username", "First_Name", "Last_Name", "Preferences", "Password", "Company_Name", "Industry") VALUES ('AlexLee_33', 'Alexander', 'Lee', 'Two-Factor Authentication', 'yT6#sVp@8X*e', 'Oracle Corporation', 'Technology');


--
-- TOC entry 3677 (class 0 OID 16498)
-- Dependencies: 220
-- Data for Name: date; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.date ("Date_id", "Year", "Month", "Day") VALUES ('8jgT3qKpL', 2023, 3, 19);
INSERT INTO public.date ("Date_id", "Year", "Month", "Day") VALUES ('5rTf2eVhJ', 2023, 3, 27);
INSERT INTO public.date ("Date_id", "Year", "Month", "Day") VALUES ('d7fE2cNtK', 2023, 3, 14);
INSERT INTO public.date ("Date_id", "Year", "Month", "Day") VALUES ('9kLp6mJhG', 2023, 3, 5);
INSERT INTO public.date ("Date_id", "Year", "Month", "Day") VALUES ('cVfR6rTbP', 2023, 3, 22);
INSERT INTO public.date ("Date_id", "Year", "Month", "Day") VALUES ('6tGn5bKjH', 2023, 3, 31);
INSERT INTO public.date ("Date_id", "Year", "Month", "Day") VALUES ('mQ8r2wFxZ', 2023, 3, 11);
INSERT INTO public.date ("Date_id", "Year", "Month", "Day") VALUES ('1hN7kRtS4', 2023, 3, 8);
INSERT INTO public.date ("Date_id", "Year", "Month", "Day") VALUES ('4sGt9nQkL', 2023, 3, 26);
INSERT INTO public.date ("Date_id", "Year", "Month", "Day") VALUES ('aB8t3mKpR', 2023, 3, 3);


--
-- TOC entry 3681 (class 0 OID 16648)
-- Dependencies: 224
-- Data for Name: email; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.email ("Username", "Email") VALUES ('BellaNguyen10', 'isabella.nguyen.2004@gmail.com');
INSERT INTO public.email ("Username", "Email") VALUES ('HarperBrowny', 'harperbrown1975@gmail.com');
INSERT INTO public.email ("Username", "Email") VALUES ('EthanAnder12', 'ethan.anderson.1998@gmail.com');
INSERT INTO public.email ("Username", "Email") VALUES ('CalexDavis', 'caleb.davis.1986@gmail.com');
INSERT INTO public.email ("Username", "Email") VALUES ('MiaEdwards21', 'mia.edwards.2003@gmail.com');
INSERT INTO public.email ("Username", "Email") VALUES ('BenjFranklin88', 'benjamin.franklin.1990@gmail.com');
INSERT INTO public.email ("Username", "Email") VALUES ('ChloeGarciaX', 'chloe.garcia.2001@gmail.com');
INSERT INTO public.email ("Username", "Email") VALUES ('WilliamHernezz', 'william.hernandez.1995@gmail.com');
INSERT INTO public.email ("Username", "Email") VALUES ('MadisonJohno', 'madison.johnson.1999@gmail.com');
INSERT INTO public.email ("Username", "Email") VALUES ('AlexLee_33', 'alexander.lee.1982@gmail.com');


--
-- TOC entry 3678 (class 0 OID 16513)
-- Dependencies: 221
-- Data for Name: follows; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3674 (class 0 OID 16461)
-- Dependencies: 217
-- Data for Name: report; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.report ("Report_id", "Report_name", "Report_description", "Username", "Date_id") VALUES ('tK9PjN', 'Apple User Sentiment Analysis Report', 'Our analysis of the top 100 subreddit posts related to Apple reveals a predominantly positive sentiment towards the brand. Out of the 100 posts analyzed, 65% were found to have a positive sentiment, 20% were neutral, and 15% had a negative sentiment. Users praised the quality of Apple''s products, particularly the iPhone, as well as the company''s commitment to customer service. Negative sentiment was primarily focused on the perceived high prices of Apple''s products and the limitations of the company''s software.', 'BellaNguyen10', '8jgT3qKpL');
INSERT INTO public.report ("Report_id", "Report_name", "Report_description", "Username", "Date_id") VALUES ('5bH6Qw', 'Google User Sentiment Analysis Report', 'Our analysis of the top 100 subreddit posts related to Google reveals a mostly neutral sentiment towards the brand. Out of the 100 posts analyzed, 50% were found to be neutral, 30% were positive, and 20% had a negative sentiment. Users discussed a variety of topics related to Google, including the company''s search engine, advertising practices, and software products. Positive sentiment was focused on the usefulness of Google''s products, while negative sentiment was primarily centered around privacy concerns.', 'HarperBrowny', '5rTf2eVhJ');
INSERT INTO public.report ("Report_id", "Report_name", "Report_description", "Username", "Date_id") VALUES ('8mD3Rn', 'Amazon User Sentiment Analysis Report', 'Our analysis of the top 100 subreddit posts related to Amazon reveals a predominantly positive sentiment towards the brand. Out of the 100 posts analyzed, 75% were found to have a positive sentiment, 15% were neutral, and 10% had a negative sentiment. Users praised the convenience and speed of Amazon''s delivery service, as well as the wide variety of products available for purchase. Negative sentiment was primarily focused on the company''s labor practices and perceived negative impact on small businesses.', 'EthanAnder12', 'd7fE2cNtK');
INSERT INTO public.report ("Report_id", "Report_name", "Report_description", "Username", "Date_id") VALUES ('sF2vJg', 'Netflix User Sentiment Analysis Report', 'Our analysis of the top 100 subreddit posts related to Netflix reveals a mostly positive sentiment towards the brand. Out of the 100 posts analyzed, 70% were found to have a positive sentiment, 15% were neutral, and 15% had a negative sentiment. Users praised the quality of Netflix''s original programming, as well as the ease of use of the streaming service. Negative sentiment was primarily focused on the perceived lack of content variety and issues with buffering or streaming quality.', 'CalexDavis', '9kLp6mJhG');
INSERT INTO public.report ("Report_id", "Report_name", "Report_description", "Username", "Date_id") VALUES ('7dL4Cp', 'BMW User Sentiment Analysis Report', 'Our analysis of the top 100 subreddit posts related to BMW reveals a mostly positive sentiment towards the brand. Out of the 100 posts analyzed, 60% were found to have a positive sentiment, 20% were neutral, and 20% had a negative sentiment. Users praised the performance and design of BMW''s vehicles, particularly the M series, as well as the company''s customer service. Negative sentiment was primarily focused on the perceived high prices of BMW''s cars and potential maintenance issues.', 'MiaEdwards21', 'cVfR6rTbP');
INSERT INTO public.report ("Report_id", "Report_name", "Report_description", "Username", "Date_id") VALUES ('cV2gMh', 'Tesla User Sentiment Analysis Report', 'Our analysis of the top 100 subreddit posts related to Tesla reveals a predominantly positive sentiment towards the brand. Out of the 100 posts analyzed, 80% were found to have a positive sentiment, 10% were neutral, and 10% had a negative sentiment. Users praised the performance and innovation of Tesla''s electric cars, as well as the company''s commitment to sustainability. Negative sentiment was primarily focused on perceived issues with the reliability of Tesla''s vehicles and concerns about the high price tag.', 'BenjFranklin88', '6tGn5bKjH');
INSERT INTO public.report ("Report_id", "Report_name", "Report_description", "Username", "Date_id") VALUES ('6rT7yN', 'Android User Sentiment Analysis Report', 'Our analysis of the top 100 subreddit posts related to Android reveals a mostly positive sentiment towards the brand. Out of the 100 posts analyzed, 70% were found to have a positive sentiment, 20% were neutral, and 10% had a negative sentiment. Users praised the customization options and user-friendly interface of Android devices, as well as the variety of models available at different price points. Negative sentiment was primarily focused on perceived issues with the performance of some Android devices.', 'ChloeGarciaX', 'mQ8r2wFxZ');
INSERT INTO public.report ("Report_id", "Report_name", "Report_description", "Username", "Date_id") VALUES ('pK9fXq', 'Bing User Sentiment Analysis Report', 'Our analysis of the top 100 subreddit posts related to Bing reveals a mostly neutral sentiment towards the brand. Out of the 100 posts analyzed, 60% were found to be neutral and 25% were positive, while 15% had a negative sentiment. Users discussed a variety of topics related to Bing, including the effectiveness of the search engine, the usefulness of Bing Maps, and the integration of Bing with other Microsoft products. Positive sentiment was primarily focused on the accuracy and relevance of Bing search results, while negative sentiment was centered around the perceived inferiority of Bing compared to other search engines.', 'WilliamHernezz', '1hN7kRtS4');
INSERT INTO public.report ("Report_id", "Report_name", "Report_description", "Username", "Date_id") VALUES ('jL5bD8', 'SpaceX User Sentiment Analysis Report', 'Our analysis of the top 100 subreddit posts related to SpaceX reveals a predominantly positive sentiment towards the brand. Out of the 100 posts analyzed, 75% were found to have a positive sentiment, 10% were neutral, and 15% had a negative sentiment. Users praised the innovation and progress of SpaceX in the field of space exploration, particularly in the areas of rocket technology and reusable spacecraft. Negative sentiment was primarily focused on concerns about safety and environmental impact.', 'MadisonJohno', '4sGt9nQkL');
INSERT INTO public.report ("Report_id", "Report_name", "Report_description", "Username", "Date_id") VALUES ('4sF1vG', 'Microsoft User Sentiment Analysis Report', 'Our analysis of the top 100 subreddit posts related to Microsoft reveals a mostly positive sentiment towards the brand. Out of the 100 posts analyzed, 65% were found to have a positive sentiment, 20% were neutral, and 15% had a negative sentiment. Users discussed a variety of Microsoft products and services, including Windows, Office, and the Xbox gaming console. Positive sentiment was focused on the usefulness and functionality of Microsoft''s products, while negative sentiment was primarily centered around perceived issues with software bugs and glitches.', 'AlexLee_33', 'aB8t3mKpR');


--
-- TOC entry 3679 (class 0 OID 16543)
-- Dependencies: 222
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.role ("Role_name", "Username") VALUES ('Admin', 'BellaNguyen10');
INSERT INTO public.role ("Role_name", "Username") VALUES ('Admin', 'HarperBrowny');
INSERT INTO public.role ("Role_name", "Username") VALUES ('Client', 'EthanAnder12');
INSERT INTO public.role ("Role_name", "Username") VALUES ('Client', 'CalexDavis');
INSERT INTO public.role ("Role_name", "Username") VALUES ('Client', 'MiaEdwards21');
INSERT INTO public.role ("Role_name", "Username") VALUES ('Client', 'BenjFranklin88');
INSERT INTO public.role ("Role_name", "Username") VALUES ('Client', 'ChloeGarciaX');
INSERT INTO public.role ("Role_name", "Username") VALUES ('Client', 'WilliamHernezz');
INSERT INTO public.role ("Role_name", "Username") VALUES ('Client', 'MadisonJohno');
INSERT INTO public.role ("Role_name", "Username") VALUES ('Client', 'AlexLee_33');


--
-- TOC entry 3676 (class 0 OID 16483)
-- Dependencies: 219
-- Data for Name: sentiment_value; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.sentiment_value ("Sentiment_id", "Score", "Rolling_average", "Date_id", "URL") VALUES ('34789231', 78, 59.4, '8jgT3qKpL', 'https://www.reddit.com/r/apple/');
INSERT INTO public.sentiment_value ("Sentiment_id", "Score", "Rolling_average", "Date_id", "URL") VALUES ('82946178', 62, 63.4, '5rTf2eVhJ', 'https://www.reddit.com/r/microsoft/');
INSERT INTO public.sentiment_value ("Sentiment_id", "Score", "Rolling_average", "Date_id", "URL") VALUES ('17328556', 57, 61.8, 'd7fE2cNtK', 'https://www.reddit.com/r/google/');
INSERT INTO public.sentiment_value ("Sentiment_id", "Score", "Rolling_average", "Date_id", "URL") VALUES ('69012499', 76, 60.6, '9kLp6mJhG', 'https://www.reddit.com/r/bing/');
INSERT INTO public.sentiment_value ("Sentiment_id", "Score", "Rolling_average", "Date_id", "URL") VALUES ('54891267', 68, 56.8, 'cVfR6rTbP', 'https://www.reddit.com/r/teslamotors/');
INSERT INTO public.sentiment_value ("Sentiment_id", "Score", "Rolling_average", "Date_id", "URL") VALUES ('92503712', 71, 59.2, '6tGn5bKjH', 'https://www.reddit.com/r/amazon/');
INSERT INTO public.sentiment_value ("Sentiment_id", "Score", "Rolling_average", "Date_id", "URL") VALUES ('37160943', 73, 61.4, 'mQ8r2wFxZ', 'https://www.reddit.com/r/Android/');
INSERT INTO public.sentiment_value ("Sentiment_id", "Score", "Rolling_average", "Date_id", "URL") VALUES ('60284305', 59, 57.4, '1hN7kRtS4', 'https://www.reddit.com/r/netflix/');
INSERT INTO public.sentiment_value ("Sentiment_id", "Score", "Rolling_average", "Date_id", "URL") VALUES ('81472683', 64, 58.6, '4sGt9nQkL', 'https://www.reddit.com/r/BMW/');
INSERT INTO public.sentiment_value ("Sentiment_id", "Score", "Rolling_average", "Date_id", "URL") VALUES ('26879391', 67, 58.8, 'aB8t3mKpR', 'https://www.reddit.com/r/spacex/');


--
-- TOC entry 3673 (class 0 OID 16456)
-- Dependencies: 216
-- Data for Name: subreddit; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.subreddit ("URL", "Member_count", "Subreddit_description", "Report_id") VALUES ('https://www.reddit.com/r/apple/', 3881045, 'An unofficial community to discuss Apple devices and software, including news, rumors, opinions and analysis pertaining to the company located at One Apple Park Way.', 'tK9PjN');
INSERT INTO public.subreddit ("URL", "Member_count", "Subreddit_description", "Report_id") VALUES ('https://www.reddit.com/r/microsoft/', 433562, 'Reddit''s home for all things Microsoft Surface, Xbox, Windows, and more!', '5bH6Qw');
INSERT INTO public.subreddit ("URL", "Member_count", "Subreddit_description", "Report_id") VALUES ('https://www.reddit.com/r/google/', 476290, 'For news and announcements from and about Google', '8mD3Rn');
INSERT INTO public.subreddit ("URL", "Member_count", "Subreddit_description", "Report_id") VALUES ('https://www.reddit.com/r/bing/', 2903, 'Microsoft Bing is more than just search. Bing is the only search engine that rewards you for your curiosity.', 'sF2vJg');
INSERT INTO public.subreddit ("URL", "Member_count", "Subreddit_description", "Report_id") VALUES ('https://www.reddit.com/r/teslamotors/', 1465804, 'The original Tesla community on Reddit.', '7dL4Cp');
INSERT INTO public.subreddit ("URL", "Member_count", "Subreddit_description", "Report_id") VALUES ('https://www.reddit.com/r/amazon/', 97288, 'All things Amazon: Amazon.com, Amazon Prime, Prime Video, AWS, Kindle, Echo, and more!', 'cV2gMh');
INSERT INTO public.subreddit ("URL", "Member_count", "Subreddit_description", "Report_id") VALUES ('https://www.reddit.com/r/Android/', 2696891, 'Android news, reviews, tips, and discussions about rooting, tutorials, and apps.', '6rT7yN');
INSERT INTO public.subreddit ("URL", "Member_count", "Subreddit_description", "Report_id") VALUES ('https://www.reddit.com/r/netflix/', 2188277, 'Unofficial Netflix discussion, and all things Netflix related!', 'pK9fXq');
INSERT INTO public.subreddit ("URL", "Member_count", "Subreddit_description", "Report_id") VALUES ('https://www.reddit.com/r/BMW/', 265611, 'This sub-reddit is dedicated to everything related to BMW vehicles, tuning, racing, and more.', 'jL5bD8');
INSERT INTO public.subreddit ("URL", "Member_count", "Subreddit_description", "Report_id") VALUES ('https://www.reddit.com/r/spacex/', 1828099, 'Welcome to r/SpaceX, the premier SpaceX discussion community and the largest fan-run board on the American aerospace company SpaceX.', '4sF1vG');


--
-- TOC entry 3675 (class 0 OID 16473)
-- Dependencies: 218
-- Data for Name: topic; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.topic ("Topic_name", "Topic_description", "URL") VALUES ('Apple', 'An unofficial community to discuss Apple devices and software, including news, rumors, opinions and analysis pertaining to the company located at One Apple Park Way.', 'https://www.reddit.com/r/apple/');
INSERT INTO public.topic ("Topic_name", "Topic_description", "URL") VALUES ('Microsoft', 'Reddit''s home for all things Microsoft Surface, Xbox, Windows, and more!', 'https://www.reddit.com/r/microsoft/');
INSERT INTO public.topic ("Topic_name", "Topic_description", "URL") VALUES ('Google', 'For news and announcements from and about Google', 'https://www.reddit.com/r/google/');
INSERT INTO public.topic ("Topic_name", "Topic_description", "URL") VALUES ('Bing', 'Microsoft Bing is more than just search. Bing is the only search engine that rewards you for your curiosity.', 'https://www.reddit.com/r/bing/');
INSERT INTO public.topic ("Topic_name", "Topic_description", "URL") VALUES ('Teslamotors', 'The original Tesla community on Reddit.', 'https://www.reddit.com/r/teslamotors/');
INSERT INTO public.topic ("Topic_name", "Topic_description", "URL") VALUES ('Amazon', 'All things Amazon: Amazon.com, Amazon Prime, Prime Video, AWS, Kindle, Echo, and more!', 'https://www.reddit.com/r/amazon/');
INSERT INTO public.topic ("Topic_name", "Topic_description", "URL") VALUES ('Android', 'Android news, reviews, tips, and discussions about rooting, tutorials, and apps.', 'https://www.reddit.com/r/Android/');
INSERT INTO public.topic ("Topic_name", "Topic_description", "URL") VALUES ('Netflix', 'Unofficial Netflix discussion, and all things Netflix related!', 'https://www.reddit.com/r/netflix/');
INSERT INTO public.topic ("Topic_name", "Topic_description", "URL") VALUES ('BMW', 'This sub-reddit is dedicated to everything related to BMW vehicles, tuning, racing, and more.', 'https://www.reddit.com/r/BMW/');
INSERT INTO public.topic ("Topic_name", "Topic_description", "URL") VALUES ('SpaceX', 'Welcome to r/SpaceX, the premier SpaceX discussion community and the largest fan-run board on the American aerospace company SpaceX.', 'https://www.reddit.com/r/spacex/');


--
-- TOC entry 3671 (class 0 OID 16431)
-- Dependencies: 214
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3501 (class 2606 OID 16435)
-- Name: user USER_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT "USER_pkey" PRIMARY KEY ("Username");


--
-- TOC entry 3503 (class 2606 OID 16590)
-- Name: admin admin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin
    ADD CONSTRAINT admin_pkey PRIMARY KEY ("Username");


--
-- TOC entry 3519 (class 2606 OID 16592)
-- Name: client client_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT client_pkey PRIMARY KEY ("Username");


--
-- TOC entry 3513 (class 2606 OID 16502)
-- Name: date date_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.date
    ADD CONSTRAINT date_pkey PRIMARY KEY ("Date_id");


--
-- TOC entry 3521 (class 2606 OID 16652)
-- Name: email email_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email
    ADD CONSTRAINT email_pkey PRIMARY KEY ("Username", "Email");


--
-- TOC entry 3515 (class 2606 OID 16517)
-- Name: follows follows_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.follows
    ADD CONSTRAINT follows_pkey PRIMARY KEY ("Username", "URL");


--
-- TOC entry 3507 (class 2606 OID 16467)
-- Name: report report_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT report_pkey PRIMARY KEY ("Report_id");


--
-- TOC entry 3517 (class 2606 OID 16547)
-- Name: role role_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT role_pkey PRIMARY KEY ("Role_name", "Username");


--
-- TOC entry 3511 (class 2606 OID 16487)
-- Name: sentiment_value sentiment_value_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sentiment_value
    ADD CONSTRAINT sentiment_value_pkey PRIMARY KEY ("Sentiment_id");


--
-- TOC entry 3505 (class 2606 OID 16460)
-- Name: subreddit subreddit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subreddit
    ADD CONSTRAINT subreddit_pkey PRIMARY KEY ("URL");


--
-- TOC entry 3509 (class 2606 OID 16564)
-- Name: topic topic_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.topic
    ADD CONSTRAINT topic_pkey PRIMARY KEY ("URL", "Topic_name");


--
-- TOC entry 3523 (class 2606 OID 16613)
-- Name: report Date_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT "Date_id_fkey" FOREIGN KEY ("Date_id") REFERENCES public.date("Date_id") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- TOC entry 3525 (class 2606 OID 16623)
-- Name: sentiment_value Date_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sentiment_value
    ADD CONSTRAINT "Date_id_fkey" FOREIGN KEY ("Date_id") REFERENCES public.date("Date_id") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- TOC entry 3522 (class 2606 OID 16628)
-- Name: subreddit Report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subreddit
    ADD CONSTRAINT "Report_id_fkey" FOREIGN KEY ("Report_id") REFERENCES public.report("Report_id") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- TOC entry 3526 (class 2606 OID 16618)
-- Name: sentiment_value URL_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sentiment_value
    ADD CONSTRAINT "URL_fkey" FOREIGN KEY ("URL") REFERENCES public.subreddit("URL") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- TOC entry 3527 (class 2606 OID 16598)
-- Name: follows URL_pkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.follows
    ADD CONSTRAINT "URL_pkey" FOREIGN KEY ("URL") REFERENCES public.subreddit("URL") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- TOC entry 3524 (class 2606 OID 16633)
-- Name: topic URL_pkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.topic
    ADD CONSTRAINT "URL_pkey" FOREIGN KEY ("URL") REFERENCES public.subreddit("URL") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


--
-- TOC entry 3528 (class 2606 OID 16678)
-- Name: email user_pkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.email
    ADD CONSTRAINT user_pkey FOREIGN KEY ("Username") REFERENCES public."user"("Username") ON UPDATE CASCADE ON DELETE CASCADE NOT VALID;


-- Completed on 2023-03-12 12:35:56 MDT

--
-- PostgreSQL database dump complete
--

