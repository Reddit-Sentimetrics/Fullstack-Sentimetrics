const express = require("express");
const app = express();
const cors = require("cors");
const pool = require("./db");
const crypto = require('crypto');


//middleware
 
app.use(cors());

app.use(express.json());

app.use((req, res, next) => {
  res.setHeader("Content-Type", "application/json");
  next();
});

//ROUTES

//login

app.post("/login", async (req, res) => {
  const { username, password } = req.body;

  try {
    const result = await pool.query(
      'SELECT * FROM public.user WHERE "Username" = $1 AND "Password" = $2',
      [username, password]
    );

    if (result.rowCount === 1) {
      const user = result.rows[0];
      const isAdminResult = await pool.query(
        'SELECT * FROM public.admin WHERE "Username" = $1',
        [user.Username]
      );

      const isAdmin = isAdminResult.rowCount === 1;
      res
        .status(200)
        .json({ message: "Logged in successfully", user, isAdmin });
    } else {
      res.status(401).send("Invalid username or password");
    }
  } catch (err) {
    console.error(err);
    res.status(500).send("Internal server error");
  }
});

app.get("/data", async (req, res) => {
  try {
    // Replace this query with the data you want to retrieve
    const result = await pool.query('SELECT * FROM "report"');
    res.status(200).json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).send("Internal server error");
  }
});



//check is admin

app.get("/is-admin/:username", async (req, res) => {
  const { username } = req.params;

  try {
    const result = await pool.query(
      'SELECT * FROM public.admin WHERE "Username" = $1',
      [username]
    );

    if (result.rowCount === 1) {
      res.status(200).json({ isAdmin: true });
    } else {
      res.status(200).json({ isAdmin: false });
    }
  } catch (err) {
    console.error(err);
    res.status(500).send("Internal server error");
  }
});

// Basic retrieval query
app.get("/basic-retrieval", async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM "user"');
    res.status(200).json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).send("Internal server error");
  }
});

// Retrieval query with ordered results
app.get("/ordered-results", async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT * FROM "user" ORDER BY "Last_Name"'
    );
    res.status(200).json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).send("Internal server error");
  }
});

// Nested retrieval query
app.get("/nested-retrieval", async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT * FROM "user" WHERE "Username" IN (SELECT "Username" FROM public.admin)'
    );
    res.setHeader("Content-Type", "application/json");

    res.status(200).json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).send("Internal server error");
  }
});

// Retrieval query using joined tables
app.get("/joined-tables", async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT u."Username", u."First_Name", u."Last_Name", e."Email" FROM public."user" u JOIN public.email e ON u."Username" = e."Username"'
    );
    res.setHeader("Content-Type", "application/json");

    res.status(200).json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).send("Internal server error");
  }
});

// ...

// Insert operation that affects more than one table
app.post("/insert-operation", async (req, res) => {
  const { username, firstName, lastName, email } = req.body;

  try {
    await pool.query("BEGIN");
    const newUser = await pool.query(
      'INSERT INTO public."user" ("Username", "First_Name", "Last_Name") VALUES ($1, $2, $3) RETURNING *',
      [username, firstName, lastName]
    );
    await pool.query(
      'INSERT INTO public."email" ("Username", "Email") VALUES ($1, $2)',
      [username, email]
    );
    await pool.query("COMMIT");

    res.setHeader("Content-Type", "application/json");

    res.status(200).json(newUser.rows[0]);
  } catch (err) {
    await pool.query("ROLLBACK");
    console.error(err);
    res.status(500).send("Internal server error");
  }
});

// Update operation with any necessary triggers
app.post("/update-operation", async (req, res) => {
  const { username, firstName, lastName } = req.body;

  try {
    const updatedUser = await pool.query(
      'UPDATE public."user" SET "First_Name" = $1, "Last_Name" = $2 WHERE "Username" = $3 RETURNING *',
      [firstName, lastName, username]
    );

    // Implement trigger-like behavior here if needed
    res.setHeader("Content-Type", "application/json");

    res.status(200).json(updatedUser.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).send("Internal server error");
  }
});

// ...

// Deletion operation with any necessary triggers, etc.
app.get("/delete-operation", async (req, res) => {
  try {
    await pool.query("BEGIN");
    await pool.query('DELETE FROM public."email" WHERE "Username" = $1', [
      "user_to_delete",
    ]);
    const deletedUser = await pool.query(
      'DELETE FROM public."user" WHERE "Username" = $1 RETURNING *',
      ["user_to_delete"]
    );
    await pool.query("COMMIT");

    // Implement trigger-like behavior here if needed
    res.setHeader("Content-Type", "application/json");

    res.status(200).json(deletedUser.rows[0]);
  } catch (err) {
    await pool.query("ROLLBACK");
    console.error(err);
    res.status(500).send("Internal server error");
  }
});

/* 

  ADMIN PAGE SUB */ 
  

  app.get('/get-subreddits', async (req, res) => {
    try {
      const result = await pool.query(`
        SELECT s."URL", s."Member_count", s."Subreddit_description", s."Report_id", sv."Score", sv."Rolling_average"
        FROM subreddit s
        LEFT JOIN sentiment_value sv ON s."URL" = sv."URL"
      `);
      res.send(result.rows);
    } catch (error) {
      console.error('Error fetching subreddits:', error);
      res.status(500).send('Error fetching subreddits');
    }
  });
  
  
  app.post('/update-score', async (req, res) => {
    try {
      const { url, score } = req.body;
      await pool.query('UPDATE public."sentiment_value" SET "Score" = $1 WHERE "URL" = $2', [
        score,
        url,
      ]);
      res.status(200).send('Score updated successfully');
    } catch (err) {
      console.error(err);
      res.status(500).send('Error updating score');
    }
  });
  





//FOLLOW OPERATIONS

// Follow a subreddit
app.post("/follow", async (req, res) => {
  const { username, url } = req.body;

  try {
    await pool.query(
      'INSERT INTO public.follows ("Username", "URL") VALUES ($1, $2)',
      [username, url]
    );
    res.status(200).send("Subreddit followed");
  } catch (err) {
    console.error(err);
    res.status(500).send("Internal server error");
  }
});

//followed subreddits
app.get("/followedSubreddits/:username", async (req, res) => {
  const { username } = req.params;
  try {
    const result = await pool.query(
      `SELECT f."URL", s."Score"
       FROM public."follows" f
       JOIN public."sentiment_value" s ON f."URL" = s."URL"
       WHERE f."Username" = $1
       AND s."Date_id" = (
         SELECT MAX("Date_id")
         FROM public."sentiment_value"
         WHERE "URL" = f."URL"
       )`,
      [username]
    );
    res.status(200).json(result.rows);
  } catch (error) {
    console.error(error);
    res.status(500).send("Internal server error");
  }
});
//Generate a report

app.post('/create-report', async (req, res) => {
  const { reportName, reportDescription, username } = req.body;

  // Get the current date
  const currentDate = new Date();
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth() + 1; // Months are zero-based
  const day = currentDate.getDate();

  // Generate a unique ID for Date_id
  const dateId = crypto.randomUUID().substring(0,6);
  const reportId = crypto.randomUUID().substring(0,6);

  try {
    // Insert the date into the date table
   
    await pool.query(
      'INSERT INTO public."date" ("Date_id", "Year", "Month", "Day") VALUES ($1, $2, $3, $4)',
      [dateId, year, month, day]
    );
 
    // Insert the report into the report table
    // Truncate the report description to 100 characters
    const truncatedReportDescription = reportDescription.substring(0, 100);

    await pool.query(
      'INSERT INTO public."report" ("Report_id", "Report_name", "Report_description", "Username", "Date_id") VALUES ($1, $2, $3, $4, $5)',
      [reportId, reportName, truncatedReportDescription, username, dateId]
    );

    res.status(200).send('Report created successfully');
  } catch (error) {
    console.error('Error creating report:', error);
    res.status(500).send('Internal server error');
  }
});




// Unfollow a subreddit
app.post("/unfollow", async (req, res) => {
  const { username, url } = req.body;

  try {
    await pool.query(
      'DELETE FROM public.follows WHERE "Username" = $1 AND "URL" = $2',
      [username, url]
    );
    res.status(200).send("Subreddit unfollowed");
  } catch (err) {
    console.error(err);
    res.status(500).send("Internal server error");
  }
});

app.get("/subreddits", async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT "URL", "Subreddit_description", "Report_id" FROM public.subreddit'
    );
    res.status(200).json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).send("Internal server error");
  }
});

app.listen(8000, () => {
  console.log("server has started on port 8000");
});
