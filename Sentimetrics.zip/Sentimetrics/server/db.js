const Pool = require("pg").Pool;

const pool = new Pool({
    user: "postgres",
    password: "ameeno123",
    host: "localhost",
    port: 5432,
    database: "RedditSentimentrics"


});

module.exports = pool;