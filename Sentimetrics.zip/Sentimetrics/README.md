1. cd to server directory
2. run `npm install`
3. run `nodemon start' to start the server

## Client

1. cd to client directory 
2. run `npm install`
3. run `npm start` to start the client

## Database

sql file to database is in server directory